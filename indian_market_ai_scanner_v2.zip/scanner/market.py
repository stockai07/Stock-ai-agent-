import pandas as pd

def flatten_quotes(data):
    rows = []
    for key, q in data.items():
        o = q.get("ohlc", {}) or {}
        rows.append({
            "instrument_key": key,
            "symbol": q.get("symbol") or q.get("trading_symbol") or key.split("|")[-1],
            "last_price": q.get("last_price"),
            "prev_close": q.get("prev_close_price") or o.get("close"),
            "open": o.get("open"),
            "high": o.get("high"),
            "low": o.get("low"),
            "volume": o.get("volume") or q.get("volume"),
            "year_high": q.get("year_high"),
            "year_low": q.get("year_low"),
            "percent_change": q.get("percent_change"),
        })
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    numeric = ["last_price","prev_close","open","high","low","volume","year_high","year_low","percent_change"]
    for c in numeric:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    if df["percent_change"].isna().all():
        df["percent_change"] = (df["last_price"] / df["prev_close"] - 1) * 100
    return df

def add_flags(df):
    x = df.copy()
    x["range_pct"] = (x["high"] - x["low"]) / x["prev_close"] * 100
    x["near_52w_high_pct"] = (x["last_price"] / x["year_high"] - 1) * 100
    x["momentum_score"] = x["percent_change"].fillna(0) * 4 + x["range_pct"].fillna(0)
    x["breakout_watch"] = (x["near_52w_high_pct"] >= -1) & (x["percent_change"] > 0)
    x["high_movement"] = x["range_pct"] >= 4
    return x

def breadth(df):
    ch = df["percent_change"].fillna(0)
    return int((ch > 0).sum()), int((ch < 0).sum()), int((ch == 0).sum())
