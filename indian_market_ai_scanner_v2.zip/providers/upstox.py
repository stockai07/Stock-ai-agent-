import requests
import pandas as pd

BASE = "https://api.upstox.com"

class UpstoxProvider:
    def __init__(self, access_token):
        if not access_token:
            raise ValueError("UPSTOX access token is missing.")
        self.headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def get_nse_equity_instruments(self):
        urls = [
            "https://assets.upstox.com/market-quote/instruments/exchange/complete.json.gz",
            "https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz",
        ]
        last = None
        for url in urls:
            try:
                r = requests.get(url, timeout=30)
                r.raise_for_status()
                import gzip, io, json
                data = json.load(gzip.GzipFile(fileobj=io.BytesIO(r.content)))
                df = pd.DataFrame(data)
                df = df[(df["segment"] == "NSE_EQ") & (df["instrument_type"] == "EQ")]
                return df.drop_duplicates("instrument_key")
            except Exception as e:
                last = e
        raise RuntimeError(f"Could not load Upstox instrument universe: {last}")

    def full_quotes(self, instrument_keys):
        params = {"instrument_key": ",".join(instrument_keys)}
        r = requests.get(
            f"{BASE}/v3/market-quote/quotes",
            headers=self.headers, params=params, timeout=30
        )
        r.raise_for_status()
        return r.json().get("data", {})
