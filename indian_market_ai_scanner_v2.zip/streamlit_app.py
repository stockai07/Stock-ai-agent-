import os, time
import streamlit as st
from providers.upstox import UpstoxProvider
from scanner.market import flatten_quotes, add_flags, breadth

st.set_page_config(page_title="Indian Market AI Scanner", layout="wide")
st.title("🇮🇳 Indian Market AI Scanner")
st.caption("Whole-market research scanner. Data comes from the connected market-data provider.")

with st.sidebar:
    st.header("Connection")
    token = st.text_input("Upstox access token", os.getenv("UPSTOX_ACCESS_TOKEN",""), type="password")
    batch = st.slider("Batch size", 50, 500, 500, 50)
    scan = st.button("🔄 Scan whole market", type="primary")

if not token:
    st.warning("Enter your Upstox access token or add UPSTOX_ACCESS_TOKEN to Streamlit Secrets.")
    st.stop()

provider = UpstoxProvider(token)

@st.cache_data(ttl=3600)
def universe():
    return provider.get_nse_equity_instruments()

try:
    uni = universe()
except Exception as e:
    st.error(f"Universe load failed: {e}")
    st.stop()

st.success(f"NSE equity instruments available: {len(uni):,}")

if scan or "market_df" not in st.session_state:
    keys = uni["instrument_key"].dropna().astype(str).tolist()
    data = {}
    progress = st.progress(0)
    total = (len(keys) + batch - 1) // batch
    for n, i in enumerate(range(0, len(keys), batch), 1):
        try:
            data.update(provider.full_quotes(keys[i:i+batch]))
        except Exception as e:
            st.warning(f"Batch {n} failed: {e}")
        progress.progress(n/total)
    progress.empty()
    st.session_state.market_df = add_flags(flatten_quotes(data))
    st.session_state.updated = time.strftime("%Y-%m-%d %H:%M:%S")

df = st.session_state.market_df
if df.empty:
    st.error("No market data returned. Check token/API permissions and market status.")
    st.stop()

adv, dec, unc = breadth(df)
a,b,c,d = st.columns(4)
a.metric("Stocks received", f"{len(df):,}")
b.metric("Advances", adv)
c.metric("Declines", dec)
d.metric("Updated", st.session_state.updated)

t1,t2,t3,t4,t5 = st.tabs(["🔥 Momentum","📈 Breakout","📊 High Movement","🔻 Weakness","🔎 Full Market"])

with t1:
    st.dataframe(df.sort_values("momentum_score", ascending=False)[
        ["symbol","last_price","percent_change","range_pct","momentum_score"]].head(100),
        use_container_width=True, hide_index=True)
with t2:
    st.dataframe(df[df.breakout_watch].sort_values("percent_change", ascending=False)[
        ["symbol","last_price","percent_change","year_high","near_52w_high_pct"]].head(100),
        use_container_width=True, hide_index=True)
with t3:
    st.dataframe(df.sort_values("range_pct", ascending=False)[
        ["symbol","last_price","percent_change","range_pct","volume"]].head(100),
        use_container_width=True, hide_index=True)
with t4:
    st.dataframe(df.sort_values("percent_change")[[
        "symbol","last_price","percent_change","range_pct","year_low"]].head(100),
        use_container_width=True, hide_index=True)
with t5:
    st.dataframe(df.sort_values("percent_change", ascending=False),
                 use_container_width=True, hide_index=True, height=650)

st.caption("Rule-based scanner only; signals are not guarantees. This build is the market-wide foundation for the AI analysis layer.")
